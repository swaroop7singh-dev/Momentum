# Momentum Android Project

This project packages the existing Momentum web app with Capacitor for Android.

## Native notification step
Install dependencies and Android platform using a Capacitor-compatible environment:

npm install
npx cap add android
npx cap sync android

Then open/build the Android project in Android Studio or a compatible Android build environment.

The current web notification code remains in index.html. Native local notification scheduling requires replacing the browser-only schedule trigger with the Capacitor Local Notifications plugin during the next implementation step.
